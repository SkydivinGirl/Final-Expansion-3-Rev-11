This directory contains z80-assembly decrunchers contributed by Metalbrain
(metalbrain_coder@gmx.net) and improved by Antonio Villena.

The decrunchers decrunches data crunched with the raw command. the
deexo_b.asm and deexo_simple_b.asm decrunchers decrunches data crunched
backwards (with the -b flag).

The deexo_simple.asm and deexo_simple_b.asm decrunchers don't handle literal
sequences and assumes that the table for bits[i] and base[i] is aligned to a
256 boundary.

Please direct any questions about these decrunchers to Metalbrain.
