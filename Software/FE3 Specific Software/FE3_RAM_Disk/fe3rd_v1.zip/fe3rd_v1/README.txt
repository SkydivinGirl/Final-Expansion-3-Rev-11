A RAM Disk for the Final Expansion 3 (1.0.0)
============================================

FE3RD uses the extra RAM of the Final Expansion to emulate an extra disk drive.
This is a proof-of-concept release and supports SAVE, LOAD, and basic file I/O.
You can also delete a file in RAM by using the command channel or you can
replace an existing file by using "@:" as name prefix, e.g. SAVE"@:name",13.

Read the contents (directory) of the RAM drive via: LOAD"$",13

To install the RAM driver load and run "fe3rd.prg".
Keep "rddrv.bin" and "rdmain.bin" in the same place from where you load fe3rd,
because they are needed by the driver.
If you put SJLOAD$04 (i.e. SJLOAD-20 v7 for loading to $0400) in the same place too,
FE3RD will load and initialize it before it loads the RAM driver.

If you want to change the device number of the RAM disk to something else,
perhaps to use it with a program that looks for disk drives from 8 to 11
you can POKE the number to the value given in parenthesis after the device number.
E.g. (for version 1.0):
	POKE 3974,11
switches the RAM device to address 11.
(Don't do this when there are open files on the RAM drive or you will not be able
 to close them correctly!)

Supported commands on channel #15 are:
- "UI"
- "S"cratch
- "R"ename
- "P"osition (see version history)

Example:

OPEN1,13,15,"S:*":CLOSE1         : REM Deletes (scratch) all files
OPEN1,13,15,"R:NEWFILE=OLDFILE"  : REM Renames OLDFILE to NEWFILE

If a file uses one block less in RAM than on the 1541 it may be caused by the
different block sizes of real drives and the RAM disk. The RAM disk uses full
256 byte blocks, but a disk drive can only use 254 bytes of each block, because
the first two bytes of a block are used for the link to the next block of a file. 

Version history
---------------

Version 1.0: The RAM-Disk loads and runs "RDRUN" if found.

Version 0.9: The "P" command now also works for non-REL files open for reading.
It uses the same format as the SD2IEC. The first byte after "P" denotes the
channel of the respective file. The remaining two to four bytes are the file
position, starting with the least significant byte. If you send less than four
bytes for the file position, take care that you do not add CR ($0D) to the
message, or the additional byte is interpreted as part of the file position.
In BASIC always append a ';' to the PRINT# command, e.g.:
PRINT#15,"P"CHR$(2)CHR$(PL)CHR$(PH); : REM file position in PL+PH 

Version 0.8 adds REL file support (EXPERIMENTAL) use at own risk ;-)
You can open any file in REL mode, but you always have to add the record size
to the OPEN command, or it will not work. Records end with 0 or maximum size,
whichever comes first.

Since version 0.7 the RAM driver survives a RUN STOP/RESTORE or a reset, if the
module area ($A000) remains untouched.


The source code of all my FE3 utilitites is available in the SVN repository of the
Vic GUI at location:
http://vin20.googlecode.com/svn/trunk/fe3

-- 
2012/05/10 Arndt Muehlenfeld
