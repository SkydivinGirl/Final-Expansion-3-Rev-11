A RAM Disk for the Final Expansion 3 (0.3)
==========================================

FE3RD uses the extra RAM of the Final Expansion to emulate an extra disk drive.
This is a proof-of-concept release and supports SAVE, LOAD, and basic file I/O.
You can not delete or overwrite a file in RAM other than resetting your computer.
Read the contents of the RAM drive via: LOAD"$",13

To install the RAM driver load and run "fe3rd.prg".
Keep "rddrv.bin" and "rdmain.bin" in the same place from where you load fe3rd,
because they are needed by the driver.
If you put SJLOAD$04 (i.e. SJLOAD-20 v7 for loading to $0400) in the same place too,
FE3RD will load and initialize it before it loads the RAM driver.

If you want to change the device number of the RAM disk to something else,
perhaps to use it with a program that looks for disk from 8 to 11 you can
POKE the number to the value given in parenthesis after the device number.
E.g. (for version 0.3):
	POKE 4015,11
switches the RAM device to address 11.
(Don't do this when there are open files on the RAM drive!)

At present, the RAM drive stops programs like FB20 (file browser) and
VIN/Diskmenu (graphical file browser) from working for unknown reasons.
Debugging is in progress...

The source code is available in the SVN repository of the Vic GUI:
http://vin20.googlecode.com/svn/trunk/fe3

-- 
2011/09/30 Arndt Muehlenfeld