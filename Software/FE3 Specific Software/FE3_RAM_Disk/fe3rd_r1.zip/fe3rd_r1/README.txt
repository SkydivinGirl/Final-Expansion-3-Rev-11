A RAM Disk for the Final Expansion 3
====================================

FE3RD uses the extra RAM of the Final Expansion to emulate an extra disk drive.
This is a proof-of-concept release and supports SAVE, LOAD, and basic file I/O.
You can not delete or overwrite a file in RAM other than resetting your computer.
Read the contents of the RAM drive via: LOAD"$",13

To install the RAM driver load and run "fe3rd.prg".
Keep "rddrv.bin" and "rdmain.bin" in the same place from where you load fe3rd,
because they are needed by the driver.

The source code is available in the SVN repository:
http://vin20.googlecode.com/svn/trunk/fe3

-- 
2011/09/22 Arndt Muehlenfeld