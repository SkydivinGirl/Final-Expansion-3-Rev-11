MKLOADER 0.9.5 Beta
by Eric HILAIRE / Majikeyric (email:majikeyric@free.fr)

MKLOADER is a Win32 command line tool which allows to automatically
generate LOADER script files to use with the Final Expansion 3 on the VIC20.

It generates LOADER files accordingly to the content of your SD Card.

It uses PETCAT and C1541 from the VICE distribution and Exomizer by
Magnus Lind. They are included in the archive.

Simply copy all 4 files into your "Path" and launch MKLOADER into the root of
your SD Card.

MKLOADER first creates a "loader.bas" text file and then tokenizes it into a
"LOADER" program file.

MKLOADER checks if a file has a valid BASIC header and then creates an entry in
loader.bas with the needed configuration and +RUN command.

If the file has no BASIC header but if the file has a one of these
load adresses : $4000, $5000, $6000, $7000, $b0000
An entry is added with a +SYS command.

If the address is $a000, a +BLKP 0,1,2,3,5 and a +RESET commands are added
instead to deal with cartridge images.

if a disk image (d64,d71,d81) is encountered, either the first valid file in the
directory is added to the LOADER or all the valid files of the disk image are
added (accordingly to the "/A" option).

Accordingly to the "/T" option: if a text file (.TXT/.NFO/.DIZ/.SEQ) is
encountered, a VIC20 executable is generated including a viewer and the
formatted text so you can read it directly on VIC20 from the FE3 disk loader.
Exomizer is used to compress the executable.

Directories starting with a "_" character are not processed, it can help protect
a "branch" from files generation temporarily.

if you want to modify the loader on PC before tokenizing it to a VIC20 basic prg
- set /K option to keep "loader.bas" files instead of deleting them and launch
  MKLOADER
- edit loader.bas with your fave text editor and apply your modifications
- invoke petcat to tokenize loader.bas to a LOADER file :
  petcat -w2 -l 1201 -o LOADER -- loader.bas

MKLOADER options:
-----------------
Usage:   MKLOADER [/S] [/O] [/I=nn] [/K] [/T] [/A] [/TAB=nn] [/?]

/S       Process all directory structure recursively (use with caution)
/O       Force overwrite of existing "LOADER" files
/I=nn    loader line numbering increment (default=10)
/K       Keep "loader.bas" files (they are deleted by default)
/T       Create executable viewers with text of files (.TXT/.NFO/.DIZ/.SEQ)
/A       List all valid disk image entries (in D64,D71,D81 files) instead
         of just the first one
/TAB=nn  Tab lenght for executable text viewers (default=4)
/?       Display this help

Download : http://majikeyric.free.fr/wordpress/?wpdmact=process&did=MTIuaG90bGluaw==
