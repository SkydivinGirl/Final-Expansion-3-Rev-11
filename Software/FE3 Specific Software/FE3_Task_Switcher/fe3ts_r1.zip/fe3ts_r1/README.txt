A Task Switcher for the Final Expansion 3
=========================================

FE3TS allows you to have up to eight virtual environments on your VIC-20 & FE3.
FE3TS-SV is an example for the supervisor written in BASIC that demonstrates
how to use the task switcher.

You can:
- create and reset environments
- switch between them by using the restore key
- save the state of an environment
- load the state of an environment

Everything works fine unless you overwrite the 3K RAM expansion area at $0400-$0FFF.

If the restore handler doesn't work, because the NMI vector was overwritten,
just type SYS 1033 to return to the supervisor.

Usage:

LOAD"FE3TS.PRG",8,1
NEW
LOAD"FE3TS-SV.PRG",8
RUN

