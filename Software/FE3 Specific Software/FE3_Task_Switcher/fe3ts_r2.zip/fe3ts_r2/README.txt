A Task Switcher for the Final Expansion 3
=========================================
(Release 2: Contains SJLOAD 7, may not run in VICE)

FE3TS allows you to have up to eight virtual environments(tasks) on your
VIC-20 & FE3 simultaneously. FE3TS-SV is an example for the supervisor
written in BASIC that demonstrates how to use the task switcher.

You can:
- create and reset tasks
- switch between them by using the restore key (or a SYS call)
- save the state of a task
- load the state of a task

Everything works fine unless you overwrite the 3K RAM expansion area at $0400-$0FFF.

If the restore handler doesn't work, because the NMI vector was overwritten,
just type SYS 2451 to return to the supervisor.

Usage:

LOAD"FE3TS.PRG",8
RUN

(FE3TS loads and executes FE3TS-SV)

----- Multi-part loader example

The task switcher is also quite convenient, if you want to prepare a
multi-part self running (or manually switched) demo.

First, you have to prepare the parts, i.e. save them as images using the
default supervisor program from this archive using the following steps:
1) load & run FE3TS
2) create a new tasks for the program you want to run
3) switch to the task by pressing '1'
4) load & run your program
5) after it has loaded all parts press "RESTORE" to return to the supervisor
 (You could also add a call to your program, BASIC: SYS 2451, ASM: JSR $993)
6) save the task giving it a name (e.g. "PART1")
7) reset the task or create a new one
8) repeat 3-7 until you have created all parts

Second, create your own supervisor. For a program that runs 3 tasks saved
as PART1 to PART2 you could use the following program:

10 DR=PEEK(186):IFDR=0THENDR=8
20 BS=2448
30 FORI=1TO3:POKE780,I:SYSBS+6:NEXT
40 PRINTCHR$(147)CHR$(17)"LOADING PART 1"
50 N=1:F$="PART1":GOSUB500
60 PRINTCHR$(147)CHR$(17)"LOADING PART 2"
70 N=2:F$="PART2":GOSUB500
80 PRINTCHR$(147)CHR$(17)"LOADING PART 3"
90 N=3:F$="PART3":GOSUB500
100 PRINTCHR$(147)
110 POKE780,1:SYSBS+9
140 POKE780,2:SYSBS+9
150 POKE780,3:SYSBS+9
160 END
500 OPEN1,DR,0,F$
510 POKE780,N:POKE781,1:SYSBS+15
520 CLOSE1
530 RETURN

Finally, copy FE3TS.PRG, the saved tasks, and the program from above under the
name "FE3TS-SV" in a directory or D64 image and you are ready to run.
Start the show by loading and running "FE3TS.PRG".

(If you want a task to return to the supervisor after it has finished, add
SYS2451 (or JSR $993) at the end.)

----- Function list

($990)
Initialize Task Switcher

SYS 2448

($993)
Switch to Supervisor (Task 0)

SYS 2451

($996)
Initialize task n (Reset)
INPUT:
	A ... task index

POKE 780, N
SYS 2454

($999)
Switch to task N
INPUT:
	A ... task index

POKE 780, N
SYS 2457

($99C)
Write task N to disk
INPUT:
	A ... Task index
	X ... File number
OUTPUT:
	A ... Pages written

F=1
OPEN F, 8, 1, "TASK"
POKE 780, N
POKE 781, F
SYS 2460
CLOSE F

($99F)
Read task N from disk
INPUT:
	A ... Environment index
	X ... File number
OUTPUT:
	A ... Pages read

F=1
OPEN F, 8, 0, "TASK"
POKE 780, N
POKE 781, F
SYS 2463
CLOSE F

-- 
2011/11/20 A.M.
